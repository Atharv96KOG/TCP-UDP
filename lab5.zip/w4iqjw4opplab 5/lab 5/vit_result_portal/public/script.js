function getResult() {
  const rollNo = document.getElementById("rollNo").value.trim();
  const resultDiv = document.getElementById("result");

  if (!rollNo) {
    alert("Please enter a roll number!");
    return;
  }

  fetch(`/result?roll_no=${rollNo}`)
    .then(res => {
      if (!res.ok) throw new Error("Not found");
      return res.json();
    })
    .then(data => {
      resultDiv.innerHTML = `
        <h2>Result for ${data.name} (${data.roll_no})</h2>
        <table>
          <tr><th>Subject</th><th>Marks</th></tr>
          <tr><td>DAA</td><td>${data.daa}</td></tr>
          <tr><td>ML</td><td>${data.ml}</td></tr>
          <tr><td>CN</td><td>${data.cn}</td></tr>
          <tr><td>CC</td><td>${data.cc}</td></tr>
        </table>
      `;
    })
    .catch(() => {
      resultDiv.innerHTML = `<p style='color:red;'>❌ Roll number not found!</p>`;
    });
}
