const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const path = require("path");

const app = express();
app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "Nupoor@3005",
  database: " vit_results_db"
});

db.connect(err => {
  if (err) console.log("❌ Database connection failed:", err);
  else console.log("✅ Connected to MySQL database");
});

app.get("/result", (req, res) => {
  const roll_no = req.query.roll_no;
  if (!roll_no) return res.status(400).send("Roll number required!");

  const query = "SELECT * FROM students WHERE roll_no = ?";
  db.query(query, [roll_no], (err, results) => {
    if (err) return res.status(500).send("DB Error");
    if (results.length === 0) return res.status(404).send("Roll number not found");
    res.json(results[0]);
  });
});

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Server running at http://localhost:${PORT}`));
