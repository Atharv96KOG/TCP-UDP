import ProjectTabs from "@/components/ProjectTabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  GraduationCap, 
  Trophy, 
  Users, 
  TrendingUp,
  ArrowRight,
  Sparkles,
  Building2
} from "lucide-react";
import heroImage from "@/assets/vit-pune-campus.png";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-gradient-hero opacity-90"
          style={{
            backgroundImage: `url(${heroImage})`,
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundBlendMode: 'overlay'
          }}
        />
        <div className="relative z-10 container mx-auto px-4 py-20 text-center text-primary-foreground">
          <div className="max-w-4xl mx-auto space-y-8">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Building2 className="w-8 h-8" />
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                Vishwakarma Institute of Technology, Pune
              </Badge>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold leading-tight">
              Project Excellence at
              <span className="block text-transparent bg-gradient-to-r from-accent to-accent-glow bg-clip-text">
                VIT Pune
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-primary-foreground/90 max-w-3xl mx-auto leading-relaxed">
              Discover how our comprehensive project ecosystem at Vishwakarma Institute of Technology, Pune - from Software Development to Electronic Data Interchange - 
              shapes industry-ready professionals and drives innovation in engineering education.
            </p>
            
            <div className="flex flex-wrap items-center justify-center gap-4 pt-8">
              <Button 
                size="lg" 
                className="bg-accent hover:bg-accent-glow text-accent-foreground shadow-glow transition-all duration-300 group"
              >
                <Sparkles className="w-5 h-5 mr-2 group-hover:rotate-12 transition-transform" />
                Explore Projects
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-white/30 text-white hover:bg-white/10 transition-all duration-300"
              >
                <Trophy className="w-5 h-5 mr-2" />
                View Achievements
              </Button>
            </div>
          </div>
        </div>
        
        {/* Floating Stats */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-20">
          <div className="flex flex-wrap items-center justify-center gap-8 bg-white/10 backdrop-blur-sm rounded-2xl px-8 py-4 border border-white/20">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">5000+</div>
                  <div className="text-sm text-white/80">Students</div>
                </div>
                <div className="w-px h-8 bg-white/30" />
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">98%</div>
                  <div className="text-sm text-white/80">Success Rate</div>
                </div>
                <div className="w-px h-8 bg-white/30" />
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">1000+</div>
                  <div className="text-sm text-white/80">Projects</div>
                </div>
          </div>
        </div>
      </section>

      {/* Overview Cards */}
      <section className="py-16 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Why Our Projects Matter
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our integrated project approach at VIT Pune ensures students gain real-world experience 
              while contributing to meaningful technological advancement and industry innovation.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <GraduationCap className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="font-semibold mb-2">Academic Excellence</h3>
                <p className="text-sm text-muted-foreground">
                  Rigorous curriculum integrated with practical project work
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-gradient-accent rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <Users className="w-6 h-6 text-accent-foreground" />
                </div>
                <h3 className="font-semibold mb-2">Industry Collaboration</h3>
                <p className="text-sm text-muted-foreground">
                  Direct partnerships with leading technology companies
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <TrendingUp className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="font-semibold mb-2">Career Growth</h3>
                <p className="text-sm text-muted-foreground">
                  95%+ placement rate in top-tier technology companies
                </p>
              </CardContent>
            </Card>
            
            <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300 group">
              <CardContent className="p-6 text-center">
                <div className="w-12 h-12 bg-gradient-accent rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                  <Trophy className="w-6 h-6 text-accent-foreground" />
                </div>
                <h3 className="font-semibold mb-2">Innovation Focus</h3>
                <p className="text-sm text-muted-foreground">
                  Cutting-edge projects addressing real-world challenges
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Main Project Tabs */}
      <section className="py-16">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Explore Our Project Categories
            </h2>
            <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
              Each project category at VIT Pune is designed to provide comprehensive learning experiences 
              while addressing industry needs and technological advancement. Add your own projects and showcase your work!
            </p>
          </div>
          
          <ProjectTabs />
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-primary">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto space-y-6 text-primary-foreground">
            <h2 className="text-3xl md:text-4xl font-bold">
              Ready to Start Your Project Journey?
            </h2>
            <p className="text-lg opacity-90">
              Join thousands of VIT Pune students who have transformed their careers through 
              our comprehensive project-based learning approach and innovative curriculum.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4 pt-4">
              <Button 
                size="lg" 
                className="bg-accent hover:bg-accent-glow text-accent-foreground shadow-glow"
              >
                Get Started Today
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10"
              >
                Contact Faculty
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <Building2 className="w-6 h-6 text-primary" />
              <span className="font-semibold">VIT Pune Project Showcase</span>
            </div>
            <div className="text-sm text-muted-foreground">
              © 2024 Vishwakarma Institute of Technology, Pune. Excellence in Engineering Education.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;