import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Code, 
  Database, 
  Cpu, 
  BookOpen, 
  TrendingUp, 
  Users, 
  Award, 
  Target,
  CheckCircle,
  Star,
  Plus,
  Edit,
  Save,
  X
} from "lucide-react";

type ProjectType = "SDP" | "EDI" | "DT" | "COURSE";

interface ProjectData {
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  relevance: string[];
  outcomes: string[];
  examples: Array<{
    name: string;
    description: string;
    technologies: string[];
    impact: string;
  }>;
  stats: {
    completion: string;
    students: string;
    industry: string;
  };
}

const initialProjectData: Record<ProjectType, ProjectData> = {
  SDP: {
    title: "Software Development Project",
    description: "Comprehensive software solutions addressing real-world problems through systematic development methodologies.",
    icon: Code,
    relevance: [
      "Bridges theoretical knowledge with practical implementation",
      "Develops industry-ready programming skills",
      "Enhances problem-solving and analytical thinking",
      "Prepares students for software engineering roles"
    ],
    outcomes: [
      "Full-stack application development",
      "Version control and collaboration skills",
      "Testing and debugging proficiency",
      "Software architecture understanding"
    ],
    examples: [
      {
        name: "Campus Management System",
        description: "Integrated platform for student registration, course management, and academic tracking",
        technologies: ["React", "Node.js", "MongoDB", "Express"],
        impact: "Streamlined administrative processes for 10,000+ students"
      },
      {
        name: "E-Learning Platform",
        description: "Interactive online learning system with video streaming and assessment tools",
        technologies: ["Vue.js", "Python", "PostgreSQL", "Docker"],
        impact: "Enhanced remote learning capabilities during pandemic"
      }
    ],
    stats: {
      completion: "95%",
      students: "500+",
      industry: "85%"
    }
  },
  EDI: {
    title: "Electronic Data Interchange (Major Project)",
    description: "Advanced electronic data interchange systems facilitating seamless business-to-business communication and transaction processing.",
    icon: Database,
    relevance: [
      "Critical for modern supply chain management",
      "Enables automated business processes",
      "Reduces manual data entry errors by 90%",
      "Essential for enterprise integration",
      "Supports global trade standardization"
    ],
    outcomes: [
      "Enterprise-level EDI system implementation",
      "B2B communication protocol mastery",
      "Data mapping and transformation skills",
      "Compliance with industry standards (ANSI X12, EDIFACT)"
    ],
    examples: [
      {
        name: "Supply Chain EDI Network",
        description: "Complete EDI solution connecting manufacturers, distributors, and retailers",
        technologies: ["EDI Standards", "XML", "AS2", "FTPS", "API Gateway"],
        impact: "Reduced order processing time by 70% across 200+ partners"
      },
      {
        name: "Healthcare Data Exchange",
        description: "HIPAA-compliant EDI system for medical billing and insurance claims",
        technologies: ["HL7 FHIR", "ANSI X12", "Encryption", "Cloud Security"],
        impact: "Processed $50M+ in medical claims with 99.9% accuracy"
      },
      {
        name: "Financial EDI Gateway",
        description: "Secure transaction processing system for banking and financial services",
        technologies: ["ISO 20022", "SWIFT", "Blockchain", "Microservices"],
        impact: "Handles 100,000+ daily transactions with real-time processing"
      }
    ],
    stats: {
      completion: "98%",
      students: "150+",
      industry: "92%"
    }
  },
  DT: {
    title: "Digital Technology Projects",
    description: "Cutting-edge digital transformation initiatives leveraging emerging technologies for innovative solutions.",
    icon: Cpu,
    relevance: [
      "Addresses digital transformation needs",
      "Incorporates AI and machine learning",
      "Focuses on IoT and smart systems",
      "Prepares for Industry 4.0 demands"
    ],
    outcomes: [
      "AI/ML model development and deployment",
      "IoT system design and implementation",
      "Cloud-native application architecture",
      "Digital innovation mindset"
    ],
    examples: [
      {
        name: "Smart Campus IoT System",
        description: "IoT-enabled campus monitoring with sensors for energy, security, and environment",
        technologies: ["Arduino", "Raspberry Pi", "AWS IoT", "Machine Learning"],
        impact: "30% reduction in energy consumption campus-wide"
      },
      {
        name: "AI-Powered Student Assistant",
        description: "Chatbot providing 24/7 academic and administrative support to students",
        technologies: ["NLP", "TensorFlow", "Python", "Cloud Functions"],
        impact: "Resolved 80% of student queries automatically"
      }
    ],
    stats: {
      completion: "90%",
      students: "300+",
      industry: "88%"
    }
  },
  COURSE: {
    title: "Course Projects",
    description: "Specialized projects integrated within academic curriculum to reinforce theoretical concepts through practical application.",
    icon: BookOpen,
    relevance: [
      "Reinforces classroom learning",
      "Develops subject-specific skills",
      "Encourages research and innovation",
      "Builds foundation for advanced projects"
    ],
    outcomes: [
      "Subject mastery through hands-on experience",
      "Research methodology skills",
      "Technical documentation abilities",
      "Presentation and communication skills"
    ],
    examples: [
      {
        name: "Database Design Project",
        description: "Complete database solution for a real business scenario",
        technologies: ["MySQL", "ER Modeling", "SQL", "Database Optimization"],
        impact: "Students gained practical database administration skills"
      },
      {
        name: "Network Security Analysis",
        description: "Comprehensive security audit and vulnerability assessment",
        technologies: ["Wireshark", "Nmap", "Metasploit", "Security Protocols"],
        impact: "Enhanced cybersecurity awareness and practical skills"
      }
    ],
    stats: {
      completion: "96%",
      students: "1200+",
      industry: "75%"
    }
  }
};

export default function ProjectTabs() {
  const [activeTab, setActiveTab] = useState<ProjectType>("EDI");
  const [projectData, setProjectData] = useState(initialProjectData);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  const [editForm, setEditForm] = useState({
    name: "",
    description: "",
    technologies: "",
    impact: ""
  });

  const data = projectData[activeTab];
  const Icon = data.icon;

  const handleAddProject = () => {
    const newProject = {
      name: editForm.name,
      description: editForm.description,
      technologies: editForm.technologies.split(",").map(t => t.trim()),
      impact: editForm.impact
    };

    setProjectData(prev => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        examples: [...prev[activeTab].examples, newProject]
      }
    }));

    setEditForm({ name: "", description: "", technologies: "", impact: "" });
    setIsEditing(null);
  };

  const handleEditProject = (index: number) => {
    const project = data.examples[index];
    setEditForm({
      name: project.name,
      description: project.description,
      technologies: project.technologies.join(", "),
      impact: project.impact
    });
    setIsEditing(`edit-${index}`);
  };

  const handleSaveProject = (index: number) => {
    const updatedProject = {
      name: editForm.name,
      description: editForm.description,
      technologies: editForm.technologies.split(",").map(t => t.trim()),
      impact: editForm.impact
    };

    const updatedExamples = [...data.examples];
    updatedExamples[index] = updatedProject;

    setProjectData(prev => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        examples: updatedExamples
      }
    }));

    setEditForm({ name: "", description: "", technologies: "", impact: "" });
    setIsEditing(null);
  };

  const handleDeleteProject = (index: number) => {
    const updatedExamples = data.examples.filter((_, i) => i !== index);
    
    setProjectData(prev => ({
      ...prev,
      [activeTab]: {
        ...prev[activeTab],
        examples: updatedExamples
      }
    }));
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-8">
      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2 mb-8 p-1 bg-muted rounded-lg">
        {Object.entries(projectData).map(([key, project]) => {
          const ProjectIcon = project.icon;
          return (
            <Button
              key={key}
              variant={activeTab === key ? "default" : "ghost"}
              className={cn(
                "flex-1 min-w-fit transition-all duration-300",
                activeTab === key 
                  ? "bg-gradient-primary text-primary-foreground shadow-elegant" 
                  : "hover:bg-secondary"
              )}
              onClick={() => setActiveTab(key as ProjectType)}
            >
              <ProjectIcon className="w-4 h-4 mr-2" />
              {key === "EDI" ? "EDI (Major)" : key}
            </Button>
          );
        })}
      </div>

      {/* Content */}
      <div className="space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-gradient-accent rounded-xl shadow-glow">
              <Icon className="w-8 h-8 text-accent-foreground" />
            </div>
            <h2 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent">
              {data.title}
            </h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            {data.description}
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300">
            <CardContent className="p-6 text-center">
              <TrendingUp className="w-8 h-8 text-accent mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary">{data.stats.completion}</div>
              <div className="text-sm text-muted-foreground">Project Completion Rate</div>
            </CardContent>
          </Card>
          <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300">
            <CardContent className="p-6 text-center">
              <Users className="w-8 h-8 text-accent mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary">{data.stats.students}</div>
              <div className="text-sm text-muted-foreground">Students Participated</div>
            </CardContent>
          </Card>
          <Card className="border-primary/20 hover:shadow-elegant transition-all duration-300">
            <CardContent className="p-6 text-center">
              <Award className="w-8 h-8 text-accent mx-auto mb-2" />
              <div className="text-3xl font-bold text-primary">{data.stats.industry}</div>
              <div className="text-sm text-muted-foreground">Industry Placement Rate</div>
            </CardContent>
          </Card>
        </div>

        {/* Relevance & Outcomes */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-accent" />
                Project Relevance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.relevance.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5 text-accent" />
                Learning Outcomes
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {data.outcomes.map((item, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-accent mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Project Examples */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-2xl font-bold">Featured Project Examples</h3>
            <Dialog>
              <DialogTrigger asChild>
                <Button 
                  className="bg-gradient-accent text-accent-foreground hover:shadow-glow transition-all duration-300"
                  onClick={() => setIsEditing("add")}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Project
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Project</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Project Name</label>
                    <Input
                      value={editForm.name}
                      onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter project name"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Description</label>
                    <Textarea
                      value={editForm.description}
                      onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Describe the project"
                      rows={3}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Technologies (comma-separated)</label>
                    <Input
                      value={editForm.technologies}
                      onChange={(e) => setEditForm(prev => ({ ...prev, technologies: e.target.value }))}
                      placeholder="React, Node.js, MongoDB, etc."
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Impact</label>
                    <Textarea
                      value={editForm.impact}
                      onChange={(e) => setEditForm(prev => ({ ...prev, impact: e.target.value }))}
                      placeholder="Describe the project's impact"
                      rows={2}
                    />
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsEditing(null)}>
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleAddProject}
                      className="bg-gradient-primary text-primary-foreground"
                      disabled={!editForm.name || !editForm.description}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      Add Project
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {data.examples.map((example, index) => (
              <Card key={index} className="border-primary/20 hover:shadow-elegant transition-all duration-300 group relative">
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 w-8 p-0"
                      onClick={() => handleEditProject(index)}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                      onClick={() => handleDeleteProject(index)}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
                
                {isEditing === `edit-${index}` ? (
                  <div className="p-6 space-y-4">
                    <Input
                      value={editForm.name}
                      onChange={(e) => setEditForm(prev => ({ ...prev, name: e.target.value }))}
                      className="font-semibold"
                    />
                    <Textarea
                      value={editForm.description}
                      onChange={(e) => setEditForm(prev => ({ ...prev, description: e.target.value }))}
                      rows={2}
                    />
                    <Input
                      value={editForm.technologies}
                      onChange={(e) => setEditForm(prev => ({ ...prev, technologies: e.target.value }))}
                      placeholder="Technologies (comma-separated)"
                    />
                    <Textarea
                      value={editForm.impact}
                      onChange={(e) => setEditForm(prev => ({ ...prev, impact: e.target.value }))}
                      rows={2}
                    />
                    <div className="flex justify-end gap-2">
                      <Button size="sm" variant="outline" onClick={() => setIsEditing(null)}>
                        Cancel
                      </Button>
                      <Button size="sm" onClick={() => handleSaveProject(index)}>
                        <Save className="w-3 h-3 mr-1" />
                        Save
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <CardHeader>
                      <CardTitle className="text-lg group-hover:text-accent transition-colors pr-16">
                        {example.name}
                      </CardTitle>
                      <CardDescription>{example.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="text-sm font-medium">Technologies Used:</div>
                        <div className="flex flex-wrap gap-1">
                          {example.technologies.map((tech, techIndex) => (
                            <Badge key={techIndex} variant="secondary" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="p-3 bg-gradient-to-r from-accent/10 to-primary/10 rounded-lg">
                        <div className="text-sm font-medium text-accent mb-1">Impact:</div>
                        <div className="text-sm">{example.impact}</div>
                      </div>
                    </CardContent>
                  </>
                )}
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}